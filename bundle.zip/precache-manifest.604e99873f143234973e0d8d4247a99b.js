self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "92665e50821a15e4244f778b4e4c7169",
    "url": "/index.html"
  },
  {
    "revision": "3277ea5618d870f806bc",
    "url": "/static/css/2.09e62520.chunk.css"
  },
  {
    "revision": "3277ea5618d870f806bc",
    "url": "/static/js/2.82a9c8b1.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/static/js/2.82a9c8b1.chunk.js.LICENSE.txt"
  },
  {
    "revision": "3c9cd9967ac861735ece",
    "url": "/static/js/main.bdff29a9.chunk.js"
  },
  {
    "revision": "2f729f8dfb644b1198eb",
    "url": "/static/js/runtime-main.4146942f.js"
  }
]);